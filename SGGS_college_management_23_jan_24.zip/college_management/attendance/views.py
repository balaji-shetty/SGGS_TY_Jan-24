from django.shortcuts import render
from .models import Attendance
from students.models import Student

def attendance_list(request):
    attendance_records = Attendance.objects.all()
    context = {'attendance_records': attendance_records}
    return render(request, 'attendance/attendance_list.html', context)
